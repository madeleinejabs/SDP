﻿//-----------------------------------------------------------------------
// <copyright file="AssemblyInfo.cs" company="OxyPlot">
//     http://oxyplot.codeplex.com, license: MIT
// </copyright>
//-----------------------------------------------------------------------

using System.Reflection;

using NUnit.Framework;

[assembly: AssemblyTitle("OxyPlot.Tests")]
[assembly: AssemblyDescription("")]

[assembly: RequiresSTA]