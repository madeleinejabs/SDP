﻿using System.Reflection;
using System.Windows;

[assembly: AssemblyTitle("OxyPlot WPF demo - Examples")]
[assembly: AssemblyDescription("")]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]