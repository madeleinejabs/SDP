﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("SynchronousStreamingExample")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Omega Engineering, Inc.")]
[assembly: AssemblyProduct("SynchronousStreamingExample")]
[assembly: AssemblyCopyright("Copyright © 2016 Omega Engineering, Inc. All Rights Reserved")]
[assembly: AssemblyTrademark("Omega Engineering, Inc.")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("354910D6-768C-4CB7-BBA4-A5A2373E0610")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
