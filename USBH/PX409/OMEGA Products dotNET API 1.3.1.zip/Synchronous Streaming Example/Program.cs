﻿// -----------------------------------------------------------------------
// <copyright file="Program.cs" company="OMEGA Engineering, Inc.">
//   Copyright © 2016 OMEGA Engineering, Inc. All rights reserved.
// </copyright>
// -----------------------------------------------------------------------

namespace SynchronousStreamingExample
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using Omega.Products.Usb;

    public class Program
    {
        public static void Main(string[] args)
        {
            // Get a list of the detected PX409-USBH sensors.
            var devices = PX409Usbh.DetectDevices().ToList();
            if (devices.Count == 0)
            {
                Console.WriteLine("No PX409-USBH devices found. Make sure they are not in use by another application and try again.");
                Environment.Exit(1);
            }

            try
            {
                // Initialize each sensor so we can view the configuration and range.
                foreach (var d in devices)
                {
                    d.Initialize();
                }

                // Allow the user to pick a sensor to stream
                PrintSensorMenu(devices);
                int i = GetUserMenuChoice(devices.Count) - 1;
                var device = devices[i];

                // Close the sensors not chosen
                foreach (var d in devices)
                {
                    if (d != device)
                        d.Close();
                }

                // Ask user how many measurements to gather.
                Console.WriteLine();
                int totalSamples = GetUserTotalSamples();

                Console.WriteLine("Please wait for {0} measurements to be received.", totalSamples);
                var readings = StreamMeasurements(device, totalSamples);
                Console.WriteLine();
                foreach (var r in readings)
                {
                    Console.WriteLine("{0:0.00000} {1}", r, device.Units);
                }
            }
            catch (Exception ex)
            {
                // Handle any exceptions so the user isn't bothered with a Windows pop-up.
                Console.WriteLine("There was an unhandled error: {0}", ex);
                Environment.Exit(1);
            }
            finally
            {
                foreach (var d in devices)
                    d.Dispose();
            }
        }

        private static double[] StreamMeasurements(PX409Usbh device, int count)
        {
            List<double> readings = new List<double>(count);
            using (var resetEvent = new System.Threading.ManualResetEventSlim())
            {
                EventHandler<ReadingsReceivedEventArgs> handler = (s, e) =>
                {
                    readings.AddRange(e.Readings);
                    if (readings.Count >= count) { resetEvent.Set(); }
                };
                device.ReadingsReceived += handler;
                device.StartStreaming();
                resetEvent.Wait();
                device.ReadingsReceived -= handler;
                device.StopStreaming();
            }

            return readings.Take(count).ToArray();
        }

        /// <summary>
        /// Shows a menu of devices that includes device serial numbers and ranges.
        /// </summary>
        /// <param name="devices">A list of <see cref="PX409Usbh"/> devices</param>
        private static void PrintSensorMenu(IList<PX409Usbh> devices)
        {
            Console.WriteLine("Please choose a sensor: ");
            for (int i = 0; i < devices.Count; ++i)
            {
                Console.WriteLine("  {0}: {1}({2}) on {3} - {4} @ {5}", i + 1, devices[i].GetType().Name, devices[i].SerialNumber, devices[i].Port.PortName, devices[i].Range, devices[i].SampleRate);
            }

            Console.Write(">");
        }

        /// <summary>
        /// Prompt the user to enter the number of measurements they wish to take.
        /// </summary>
        /// <returns>The user's requested number of measurements.</returns>
        private static int GetUserTotalSamples()
        {
            string prompt = "How many measurements to record? ";
            Console.WriteLine(prompt);
            string response = Console.ReadLine();
            int totalSamples;
            while(!int.TryParse(response, out totalSamples))
            {
                Console.WriteLine(prompt);
                response = Console.ReadLine();
            }

            return totalSamples;
        }

        /// <summary>
        /// Prompt the user for a choice repeatedly until the make a valid selection
        /// </summary>
        /// <param name="maxOption">The largest valid choice</param>
        /// <returns>The user's choice</returns>
        private static int GetUserMenuChoice(int maxOption)
        {
            int choice = 0;
            var response = Console.ReadLine();
            while (!int.TryParse(response, out choice))
            {
                Console.Write("Invalid Choice, please try again: ");
                response = Console.ReadLine();
            }

            return choice;
        }
    }
}
