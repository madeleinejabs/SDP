﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("PX409UsbhStreamingExample")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Omega Engineering, Inc.")]
[assembly: AssemblyProduct("PX409UsbhStreamingExample")]
[assembly: AssemblyCopyright("Copyright © 2014 Omega Engineering, Inc. All Rights Reserved")]
[assembly: AssemblyTrademark("Omega Engineering, Inc.")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("48d5bee7-6761-4fa0-ab18-7030013fe083")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
