﻿//-----------------------------------------------------------------------
// <copyright file="AssemblyInfo.cs" company="OxyPlot">
//     http://oxyplot.codeplex.com, license: MIT
// </copyright>
//-----------------------------------------------------------------------

using System.Reflection;

[assembly: AssemblyTitle("OxyPlot WinForms demo - Example browser")]
[assembly: AssemblyDescription("WinForms based browser for the example library.")]