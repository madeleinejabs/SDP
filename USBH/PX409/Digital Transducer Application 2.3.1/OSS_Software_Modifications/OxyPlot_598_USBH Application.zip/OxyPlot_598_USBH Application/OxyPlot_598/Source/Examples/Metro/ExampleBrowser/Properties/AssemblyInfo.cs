﻿using System.Reflection;

[assembly: AssemblyTitle("OxyPlot Metro Example Browser")]
[assembly: AssemblyDescription("OxyPlot example browser")]
