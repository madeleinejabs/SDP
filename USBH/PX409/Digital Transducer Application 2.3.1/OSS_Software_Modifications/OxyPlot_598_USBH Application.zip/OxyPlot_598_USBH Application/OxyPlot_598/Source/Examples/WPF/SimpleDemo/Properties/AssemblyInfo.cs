﻿//-----------------------------------------------------------------------
// <copyright file="AssemblyInfo.cs" company="OxyPlot">
//     http://oxyplot.codeplex.com, license: MIT
// </copyright>
//-----------------------------------------------------------------------

using System.Reflection;
using System.Windows;

[assembly: AssemblyTitle("OxyPlot WPF demo")]
[assembly: AssemblyDescription("")]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
