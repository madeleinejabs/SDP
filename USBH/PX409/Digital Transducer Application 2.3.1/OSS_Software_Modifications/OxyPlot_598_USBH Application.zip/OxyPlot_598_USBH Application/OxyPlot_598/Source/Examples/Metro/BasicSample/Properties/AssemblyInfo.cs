﻿using System.Reflection;

[assembly: AssemblyTitle("OxyPlot Metro BasicSample")]
[assembly: AssemblyDescription("OxyPlot basic Windows Store app sample")]