﻿using System.Reflection;

[assembly: AssemblyTitle("OxyPlot.Metro")]
[assembly: AssemblyDescription("OxyPlot controls for Windows Store apps")]