OxyPlot
================================================================================
OxyPlot is an open source, cross-platform .NET plotting library.

License:       The MIT License (MIT)
Project page:  http://oxyplot.codeplex.com
Source:        https://hg.codeplex.com/oxyplot