﻿// -----------------------------------------------------------------------
// <copyright file="Program.cs" company="OMEGA Engineering, Inc.">
//   Copyright © 2014 OMEGA Engineering, Inc. All Rights Reserved.
// </copyright>
// -----------------------------------------------------------------------

namespace PX409UsbhStreamingExample
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using Omega.Products.Usb;

    public class Program
    {
        public static void Main(string[] args)
        {
            // Get a list of the detected PX409-USBH sensors.
            var devices = PX409Usbh.DetectDevices().ToList();
            if (devices.Count == 0)
            {
                Console.WriteLine("No PX409-USBH devices found. Make sure they are not in use by another application and try again.");
                Environment.Exit(1);
            }

            try
            {
                // Initialize each sensor so we can view the configuration and range.
                foreach (var d in devices)
                {
                    d.Initialize();
                }

                // Allow the user to pick a sensor to stream
                PrintSensorMenu(devices);
                int i = GetUserMenuChoice(devices.Count) - 1;
                var device = devices[i];

                // Close the sensors not chosen
                foreach (var d in devices)
                {
                    if (d != device)
                        d.Close();
                }

                Console.WriteLine();
                Console.WriteLine("Press any key to stop collecting measurements...");

                // Setup the event handler to receive new readings.
                device.ReadingsReceived += (s, e) =>
                {
                    ShowReading(e.Readings.LastOrDefault(), ((PX409Usbh)s).Units);
                };

                // Stream until the user presses a key.
                device.StartStreaming();
                Console.ReadKey();
                device.StopStreaming();
            }
            catch (Exception ex)
            {
                // Handle any exceptions so the user isn't bothered with a Windows pop-up.
                Console.WriteLine("There was an unhandled error: {0}", ex);
                Environment.Exit(1);
            }
            finally
            {
                foreach (var d in devices)
                    d.Dispose();
            }
        }

        /// <summary>
        /// Shows a menu of devices that includes device serial numbers and ranges.
        /// </summary>
        /// <param name="devices">A list of <see cref="PX409Usbh"/> devices</param>
        private static void PrintSensorMenu(IList<PX409Usbh> devices)
        {
            Console.WriteLine("Please choose a sensor: ");
            for (int i = 0; i < devices.Count; ++i)
            {
                Console.WriteLine("  {0}: {1}({2}) on {3} - {4}", i + 1, devices[i].GetType().Name, devices[i].SerialNumber, devices[i].Port.PortName, devices[i].Range);
            }

            Console.Write(">");
        }

        /// <summary>
        /// Prompt the user for a choice repeatedly until the make a valid selection
        /// </summary>
        /// <param name="maxOption">The largest valid choice</param>
        /// <returns>The user's choice</returns>
        private static int GetUserMenuChoice(int maxOption)
        {
            int choice = 0;
            var key = Console.ReadKey();
            while(!int.TryParse(key.KeyChar.ToString(), out choice) || choice < 1 || choice > maxOption)
            {
                Console.WriteLine();
                Console.Write("Invalid Choice, please try again: ");
                key = Console.ReadKey();
            }

            return choice;
        }

        /// <summary>
        /// Prints the given reading and units to the beginning of the current line in the console
        /// </summary>
        /// <param name="reading">Reading value</param>
        /// <param name="units">Units of measure</param>
        private static void ShowReading(double reading, string units)
        {
            Console.CursorLeft = 0;
            Console.Write(new string(' ', Console.WindowWidth - 1));
            Console.CursorLeft = 0;
            Console.Write("Pressure: {0} {1}", reading, units); 
        }
    }
}
