Omega .NET Products API README
================================

This package contains a .NET dll that allows you to communicate with your
Omega digital sensors. The assembly is located in the "Lib" folder. The net40
folder contains a version for .NET 4.0 or greater, and net35 contains a
version for .NET 3.5. There are also example applications illustrating how to
use the assembly in your .NET project.  This assembly currently supports the
following products:

* PX409-USB
* PX409-USBH
* TJ-USB
* UTC-USB
* RH-USB
* IR-USB
* LC411-USBH
* PX51-USBH
* IN-USBH
* PX459-485

The library makes use of the `System.Diagnostics.TraceSource` system. It uses
a trace source named, "Omega.Products". In the `App.config` file in the
examples, they show how to configure tracing so you can see the messages in
Visual Studio while debugging. Please see the (MSDN
documentation)[https://msdn.microsoft.com/en-us/library/system.diagnostics.tracesource%28v=vs.110%29.aspx]
for more information.

Examples
---------------

The example code is provided as is and without warranty. It's meant to serve
as a reference for using our basic API in your own software. The examples
require .NET 4.0 or greater to build and execute.

### PX409-USBH Streaming Example ###

The PX409-USBH Streaming Example shows how to detect, and begin streaming
measurement from your device. Measurements are received asynchronously using
the .NET event system. By streaming you're able to receive up to 1000 samples
per second.

### Synchronous Streaming Example ###

The Synchronous Streaming Example shows how to detect and begin streaming
measurements from your device. In this example the streaming and event handling
is captured in a single method that waits until a certain number of
measurements are received. This wrapping of the .NET event system can be useful
when integrating USBH support into some other software that doesn't work well
with .NET events.

Troubleshooting
---------------

If you're having issues opening the .chm help file, you may have to "unblock"
the file.

1. Right-click on the .chm file and choose properties
2. Near the bottom of the properties window, click the "Unblock" button.

License
------------------

Please see the file LICENSE.txt for licensing information.
